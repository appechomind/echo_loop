
import time
import os

def load_next_task():
    try:
        with open("next_task.txt", "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "No task found."

def log(message):
    print(f"Gizmo says: {message}")
    with open("log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"[{time.ctime()}] {message}
")

if __name__ == "__main__":
    while True:
        task = load_next_task()
        if task != "No task found.":
            log(f"New Task: {task}")
            # AI interaction logic would be here
        else:
            log("Waiting for task...")
        time.sleep(5)
